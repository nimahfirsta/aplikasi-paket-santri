-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2020 at 03:25 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paket_santri`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_asrama`
--

CREATE TABLE `data_asrama` (
  `ID_ASRAMA` int(11) NOT NULL,
  `NAMA_ASRAMA` varchar(100) DEFAULT NULL,
  `GEDUNG` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_asrama`
--

INSERT INTO `data_asrama` (`ID_ASRAMA`, `NAMA_ASRAMA`, `GEDUNG`) VALUES
(1, 'ASRAMA A', 'GEDUNG MAWAR'),
(2, 'ASRAMA B', 'GEDUNG MELATI');

-- --------------------------------------------------------

--
-- Table structure for table `data_kategori_paket`
--

CREATE TABLE `data_kategori_paket` (
  `ID_KATEGORI` int(11) NOT NULL,
  `NAMA_KATEGORI` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_kategori_paket`
--

INSERT INTO `data_kategori_paket` (`ID_KATEGORI`, `NAMA_KATEGORI`) VALUES
(1, 'Paket Kecil'),
(2, 'Paket Besar');

-- --------------------------------------------------------

--
-- Table structure for table `data_paket`
--

CREATE TABLE `data_paket` (
  `ID_PAKET` int(11) NOT NULL,
  `NAMA_PAKET` varchar(100) DEFAULT NULL,
  `TANGGAL_TERIMA` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `PENGIRIM_PAKET` varchar(100) DEFAULT NULL,
  `ISI_PAKET` varchar(200) DEFAULT NULL,
  `STATUS_PAKET` varchar(50) DEFAULT NULL,
  `ID_KATEGORI` int(11) DEFAULT NULL,
  `NIS` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_paket`
--

INSERT INTO `data_paket` (`ID_PAKET`, `NAMA_PAKET`, `TANGGAL_TERIMA`, `PENGIRIM_PAKET`, `ISI_PAKET`, `STATUS_PAKET`, `ID_KATEGORI`, `NIS`) VALUES
(1, 'Paket untuk Lala', '2020-11-02 02:07:50', 'Pak Beni', 'Buku', 'Belum Diterima', 1, 'STD000001');

-- --------------------------------------------------------

--
-- Table structure for table `data_santri`
--

CREATE TABLE `data_santri` (
  `NIS` varchar(100) NOT NULL,
  `NAMA_SANTRI` varchar(100) DEFAULT NULL,
  `ALAMAT` varchar(100) DEFAULT NULL,
  `TOTAL_PAKET` int(11) DEFAULT NULL,
  `ID_ASRAMA` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_santri`
--

INSERT INTO `data_santri` (`NIS`, `NAMA_SANTRI`, `ALAMAT`, `TOTAL_PAKET`, `ID_ASRAMA`) VALUES
('STD000001', 'LALA PUTRI', 'JL. MAWAR NO. 10', 1, 1),
('STD000002', 'RESKI PUTRA', 'JL. DANAU TOBA NO. 30', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `data_user`
--

CREATE TABLE `data_user` (
  `ID_USER` int(11) NOT NULL,
  `NAMA_USER` varchar(100) DEFAULT NULL,
  `USERNAME` varchar(100) DEFAULT NULL,
  `ID_ROLE` int(11) DEFAULT NULL,
  `PASSWORD` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_user`
--

INSERT INTO `data_user` (`ID_USER`, `NAMA_USER`, `USERNAME`, `ID_ROLE`, `PASSWORD`) VALUES
(1, 'Admin', 'admin', 1, '*4ACFE3202A5FF5CF467898FC58AAB1D615029441');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `ID_ROLE` int(11) NOT NULL,
  `NAMA_ROLE` varchar(100) DEFAULT NULL,
  `MENU` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`ID_ROLE`, `NAMA_ROLE`, `MENU`) VALUES
(1, 'ADMIN', 'CREATE, READ, UPDATE, DELETE'),
(2, 'SPV', 'CREATE, READ, UPDATE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_asrama`
--
ALTER TABLE `data_asrama`
  ADD PRIMARY KEY (`ID_ASRAMA`);

--
-- Indexes for table `data_kategori_paket`
--
ALTER TABLE `data_kategori_paket`
  ADD PRIMARY KEY (`ID_KATEGORI`);

--
-- Indexes for table `data_paket`
--
ALTER TABLE `data_paket`
  ADD PRIMARY KEY (`ID_PAKET`),
  ADD KEY `ID_KATEGORI` (`ID_KATEGORI`),
  ADD KEY `NIS` (`NIS`);

--
-- Indexes for table `data_santri`
--
ALTER TABLE `data_santri`
  ADD PRIMARY KEY (`NIS`),
  ADD KEY `ID_ASRAMA` (`ID_ASRAMA`);

--
-- Indexes for table `data_user`
--
ALTER TABLE `data_user`
  ADD PRIMARY KEY (`ID_USER`),
  ADD KEY `ID_ROLE` (`ID_ROLE`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`ID_ROLE`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_asrama`
--
ALTER TABLE `data_asrama`
  MODIFY `ID_ASRAMA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `data_kategori_paket`
--
ALTER TABLE `data_kategori_paket`
  MODIFY `ID_KATEGORI` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `data_paket`
--
ALTER TABLE `data_paket`
  MODIFY `ID_PAKET` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data_user`
--
ALTER TABLE `data_user`
  MODIFY `ID_USER` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `ID_ROLE` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `data_paket`
--
ALTER TABLE `data_paket`
  ADD CONSTRAINT `data_paket_ibfk_1` FOREIGN KEY (`ID_KATEGORI`) REFERENCES `data_kategori_paket` (`ID_KATEGORI`),
  ADD CONSTRAINT `data_paket_ibfk_2` FOREIGN KEY (`NIS`) REFERENCES `data_santri` (`NIS`);

--
-- Constraints for table `data_santri`
--
ALTER TABLE `data_santri`
  ADD CONSTRAINT `data_santri_ibfk_1` FOREIGN KEY (`ID_ASRAMA`) REFERENCES `data_asrama` (`ID_ASRAMA`);

--
-- Constraints for table `data_user`
--
ALTER TABLE `data_user`
  ADD CONSTRAINT `data_user_ibfk_1` FOREIGN KEY (`ID_ROLE`) REFERENCES `role` (`ID_ROLE`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
