<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<html>
    <div class="container">
        <div class="row">
            <div class="col">
            <h1 class="mt-2">Data Paket</h1>
            <table class="table">
  <thead>
    <tr>
      <th scope="col">Isi Paket</th>
      <th scope="col">Nama Paket</th>
      <th scope="col">Pengirim</th>
      <th scope="col">Status</th>
      <th scope="col">Tanggal Terima</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($data_paket as $dp) : ?>
    <tr>
      <td><?php echo $dp['ISI_PAKET']; ?></td>
      <td><?php echo $dp['NAMA_PAKET']; ?></td>
      <td><?php echo $dp['PENGIRIM_PAKET']; ?></td>
      <td><?php echo $dp['STATUS_PAKET']; ?></td>
      <td><?php echo $dp['TANGGAL_TERIMA']; ?></td>
      <td>
      <button type="button" class="btn btn-primary btn-sm">
          <span class="glyphicon glyphicon-edit"></span>
        </button>
      <button type="button" class="btn btn-danger btn-sm">
          <span class=" glyphicon glyphicon-trash"></span>
        </button>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
            </div>
        </div>
    </div>
</html>