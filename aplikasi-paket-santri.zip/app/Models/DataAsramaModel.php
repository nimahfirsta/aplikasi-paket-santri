<?php namespace App\Models;

use CodeIgniter\Model;

class DataAsramaModel extends Model
{
    protected $table = 'data_asrama';
    protected $primaryKey = 'id_asrama';

}