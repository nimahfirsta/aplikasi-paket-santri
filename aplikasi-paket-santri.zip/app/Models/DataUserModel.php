<?php namespace App\Models;

use CodeIgniter\Model;

class DataUserModel extends Model
{
    protected $table = 'data_user';
    protected $primaryKey = 'id_user';

}