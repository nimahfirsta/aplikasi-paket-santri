<?php namespace App\Models;

use CodeIgniter\Model;

class DataPaketModel extends Model
{
    protected $table = 'data_paket';
    protected $primaryKey = 'id_paket';

}