<?php namespace App\Models;

use CodeIgniter\Model;

class DataKategorPaketModel extends Model
{
    protected $table = 'data_kategori_paket';
    protected $primaryKey = 'id_kategori';

}