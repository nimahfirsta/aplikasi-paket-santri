<?php namespace App\Models;

use CodeIgniter\Model;

class DataSantriModel extends Model
{
    protected $table = 'data_santri';
    protected $primaryKey = 'nis';

}