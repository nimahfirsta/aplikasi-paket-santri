<?php namespace App\Controllers;

class DataSantri extends BaseController
{
    protected $dataSantriModel;

    public function __construct()
    {
        $this->dataSantriModel = new \App\Models\DataSantriModel();
    }

	public function index()
	{
        // $dataSantri = $this->dataSantriModel->findAll();

        $data['data_santri'] = $this->dataSantriModel->findAll();
        // $data = [
        //     'dataSantri' => $dataSantri
        // ];

        // echo print_r($data);
		return view('data_santri_view', $data);
    }

    public function addSantri()
    {
        
    }

	
}
