<?php namespace App\Controllers;

class DataPaket extends BaseController
{
    protected $dataPaketModel;

    public function __construct()
    {
        $this->dataPaketModel = new \App\Models\DataPaketModel();
    }

	public function index()
	{

        $data['data_paket'] = $this->dataPaketModel->findAll();
		return view('data_paket_view', $data);
    }

    public function addPaket()
    {
        
    }

	
}
